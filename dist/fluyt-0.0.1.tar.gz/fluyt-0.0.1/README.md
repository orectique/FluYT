# FluYT
 An elementary downloader for YouTube videos.

To use, clone the repository and run `python fluyt.py` from inside it. I tried to package it into an executable, but PySide6 isn't supported by most freezing standards. 

P.S. have fun installing all the dependencies. You'll need PySide6, PyQt5, and ffmpeg. I'm too evil to put them in a requirements.txt.
